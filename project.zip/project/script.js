export default{
  name: 'undified',
  instagram: '', //cukup username saja
  tiktok: '',
  github: '',
}